package com.example.HotelAlura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelAluraApplicationTests {

	@Test
	void contextLoads() {
	}

}
