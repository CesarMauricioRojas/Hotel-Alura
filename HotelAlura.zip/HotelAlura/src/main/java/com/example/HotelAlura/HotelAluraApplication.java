package com.example.HotelAlura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelAluraApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelAluraApplication.class, args);
	}

}
